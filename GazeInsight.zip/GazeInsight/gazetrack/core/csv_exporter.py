"""
Export eye tracking data to CSV format
"""
import csv
from typing import Dict, List
import io
from datetime import datetime

class CSVExporter:
    def __init__(self):
        self.session_data = None

    def export_session(self, session_data: Dict) -> str:
        """Export session data to CSV format"""
        self.session_data = session_data
        output = io.StringIO()
        writer = csv.writer(output, quoting=csv.QUOTE_MINIMAL)

        # Write session information
        self._write_session_info(writer)
        writer.writerow([])  # Empty row for separation

        # Write settings
        self._write_settings(writer)
        writer.writerow([])

        # Write analytics
        self._write_analytics(writer)
        writer.writerow([])

        # Write gaze data
        self._write_gaze_data(writer)

        return output.getvalue()

    def _write_session_info(self, writer: csv.writer):
        """Write session metadata"""
        writer.writerow(['# Session Information'])
        writer.writerow(['Field', 'Value'])
        writer.writerow(['Experiment Name', self.session_data.get('experiment_name', 'Unknown')])
        writer.writerow(['Participant ID', self.session_data.get('participant_id', 'Unknown')])
        writer.writerow(['Start Time', self._format_datetime(self.session_data.get('start_time'))])
        writer.writerow(['End Time', self._format_datetime(self.session_data.get('end_time'))])

    def _write_settings(self, writer: csv.writer):
        """Write experiment settings"""
        writer.writerow(['# Settings'])
        writer.writerow(['Setting', 'Value'])
        settings = self.session_data.get('settings', {})
        for key, value in settings.items():
            writer.writerow([key, str(value)])

    def _write_analytics(self, writer: csv.writer):
        """Write analytics data"""
        writer.writerow(['# Analytics'])
        writer.writerow(['Metric', 'Value'])
        
        analytics = self.session_data.get('analytics', {})
        screen_coverage = analytics.get('screen_coverage', {})
        
        writer.writerow(['Total Gaze Points', analytics.get('total_gaze_points', 0)])
        writer.writerow(['Average Confidence', f"{analytics.get('average_confidence', 0):.2f}"])
        writer.writerow(['Average Pupil Size', f"{analytics.get('average_pupil_size', 0):.2f}"])
        writer.writerow(['Top Screen Coverage', f"{screen_coverage.get('top', 0):.1f}%"])
        writer.writerow(['Middle Screen Coverage', f"{screen_coverage.get('middle', 0):.1f}%"])
        writer.writerow(['Bottom Screen Coverage', f"{screen_coverage.get('bottom', 0):.1f}%"])
        writer.writerow(['Fixation Count', analytics.get('fixation_count', 0)])
        writer.writerow(['Saccade Count', analytics.get('saccade_count', 0)])

    def _write_gaze_data(self, writer: csv.writer):
        """Write detailed gaze data"""
        writer.writerow(['# Gaze Data'])
        writer.writerow([
            'Timestamp',
            'X Position',
            'Y Position',
            'Confidence',
            'Pupil Size',
            'Screen Section'
        ])

        gaze_data = self.session_data.get('gaze_data', [])
        for data_point in gaze_data:
            writer.writerow([
                self._format_datetime(data_point.get('timestamp')),
                f"{data_point.get('x', 0):.2f}",
                f"{data_point.get('y', 0):.2f}",
                f"{data_point.get('confidence', 0):.3f}",
                f"{data_point.get('pupil_size', 0):.2f}",
                data_point.get('screen_section', 'unknown')
            ])

    def _format_datetime(self, dt: datetime) -> str:
        """Format datetime object to string"""
        if not dt:
            return 'N/A'
        return dt.isoformat() if isinstance(dt, datetime) else str(dt)
