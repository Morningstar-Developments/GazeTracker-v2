"""
Process and analyze eye tracking data
"""
from typing import Dict, List
import numpy as np
from datetime import datetime

class GazeDataProcessor:
    def __init__(self):
        self.current_session_data = None

    def process_session(self, session_data: Dict) -> Dict:
        """Process raw session data and calculate analytics"""
        self.current_session_data = session_data
        
        if not session_data.get('gaze_data'):
            return self._empty_analytics()

        gaze_data = session_data['gaze_data']
        return {
            'session_info': self._process_session_info(),
            'analytics': self._calculate_analytics(gaze_data),
            'heatmap_data': self._generate_heatmap_data(gaze_data)
        }

    def _process_session_info(self) -> Dict:
        """Extract and format session information"""
        session = self.current_session_data
        return {
            'experiment_name': session.get('experiment_name', 'Unknown'),
            'participant_id': session.get('participant_id', 'Unknown'),
            'start_time': session['start_time'].isoformat(),
            'end_time': session.get('end_time', datetime.now()).isoformat(),
            'duration_seconds': (session.get('end_time', datetime.now()) - 
                               session['start_time']).total_seconds()
        }

    def _calculate_analytics(self, gaze_data: List[Dict]) -> Dict:
        """Calculate various analytics from gaze data"""
        confidence_values = [d['confidence'] for d in gaze_data]
        pupil_sizes = [d['pupil_size'] for d in gaze_data if 'pupil_size' in d]
        
        screen_sections = self._calculate_screen_coverage(gaze_data)
        
        return {
            'total_gaze_points': len(gaze_data),
            'average_confidence': np.mean(confidence_values),
            'average_pupil_size': np.mean(pupil_sizes) if pupil_sizes else None,
            'screen_coverage': screen_sections,
            'fixation_count': self._calculate_fixations(gaze_data),
            'saccade_count': self._calculate_saccades(gaze_data)
        }

    def _calculate_screen_coverage(self, gaze_data: List[Dict]) -> Dict:
        """Calculate percentage of time spent looking at each screen section"""
        section_counts = {'top': 0, 'middle': 0, 'bottom': 0}
        total_points = len(gaze_data)
        
        for point in gaze_data:
            section = point.get('screen_section', 'middle')
            section_counts[section] += 1
        
        return {
            section: (count / total_points * 100) 
            for section, count in section_counts.items()
        }

    def _calculate_fixations(self, gaze_data: List[Dict]) -> int:
        """Calculate number of fixations in the gaze data"""
        # Implement fixation detection algorithm
        return len(gaze_data) // 10  # Placeholder implementation

    def _calculate_saccades(self, gaze_data: List[Dict]) -> int:
        """Calculate number of saccades in the gaze data"""
        # Implement saccade detection algorithm
        return len(gaze_data) // 15  # Placeholder implementation

    def _generate_heatmap_data(self, gaze_data: List[Dict]) -> List[Dict]:
        """Generate data for heatmap visualization"""
        return [{
            'x': d['x'],
            'y': d['y'],
            'weight': d['confidence']
        } for d in gaze_data]

    def _empty_analytics(self) -> Dict:
        """Return empty analytics structure"""
        return {
            'session_info': {
                'experiment_name': 'Unknown',
                'participant_id': 'Unknown',
                'start_time': None,
                'end_time': None,
                'duration_seconds': 0
            },
            'analytics': {
                'total_gaze_points': 0,
                'average_confidence': 0,
                'average_pupil_size': None,
                'screen_coverage': {'top': 0, 'middle': 0, 'bottom': 0},
                'fixation_count': 0,
                'saccade_count': 0
            },
            'heatmap_data': []
        }
