"""
Pydantic models for request/response validation
"""
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
from datetime import datetime

class SessionSettings(BaseModel):
    calibration_points: int = Field(default=5, ge=1, le=9)
    screen_resolution: Dict[str, int]

class SessionCreate(BaseModel):
    experiment_name: str
    participant_id: str
    settings: SessionSettings

class GazeData(BaseModel):
    timestamp: datetime
    x: float = Field(ge=0)
    y: float = Field(ge=0)
    confidence: float = Field(ge=0, le=1)
    pupil_size: Optional[float] = None
    screen_section: Optional[str] = None

class SessionResponse(BaseModel):
    id: str
    experiment_name: str
    participant_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    settings: SessionSettings
    analytics: Optional[Dict] = None

class SessionAnalytics(BaseModel):
    total_gaze_points: int
    average_confidence: float
    screen_coverage: Dict[str, float]
    fixation_count: int
    saccade_count: int
    duration_seconds: float
