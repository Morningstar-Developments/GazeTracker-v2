"""
FastAPI routes for the eye tracking application
"""
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import StreamingResponse
import io
from datetime import datetime
from typing import Dict, List

from ..core.eye_tracker import EyeTracker
from ..core.data_processor import GazeDataProcessor
from ..core.csv_exporter import CSVExporter
from .models import SessionCreate, SessionResponse, GazeData, SessionAnalytics

router = APIRouter()
eye_tracker = EyeTracker()
data_processor = GazeDataProcessor()
csv_exporter = CSVExporter()

@router.post("/sessions", response_model=SessionResponse)
async def create_session(session_data: SessionCreate):
    """Start a new eye tracking session"""
    try:
        session = eye_tracker.start_session(
            session_data.experiment_name,
            session_data.participant_id
        )
        return session
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/sessions/{session_id}/gaze")
async def add_gaze_data(session_id: str, gaze_data: GazeData):
    """Add gaze data to current session"""
    try:
        if not eye_tracker.current_session or str(eye_tracker.current_session.get('id')) != session_id:
            raise HTTPException(status_code=404, detail="Session not found")
        
        eye_tracker.current_session['gaze_data'].append(gaze_data.dict())
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/sessions/{session_id}", response_model=SessionResponse)
async def get_session(session_id: str):
    """Get session information"""
    try:
        if not eye_tracker.current_session or str(eye_tracker.current_session.get('id')) != session_id:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return eye_tracker.current_session
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/sessions/{session_id}/analytics", response_model=SessionAnalytics)
async def get_session_analytics(session_id: str):
    """Get analytics for a session"""
    try:
        if not eye_tracker.current_session or str(eye_tracker.current_session.get('id')) != session_id:
            raise HTTPException(status_code=404, detail="Session not found")
        
        processed_data = data_processor.process_session(eye_tracker.current_session)
        return processed_data['analytics']
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/sessions/{session_id}/export")
async def export_session(session_id: str):
    """Export session data to CSV"""
    try:
        if not eye_tracker.current_session or str(eye_tracker.current_session.get('id')) != session_id:
            raise HTTPException(status_code=404, detail="Session not found")
        
        csv_content = csv_exporter.export_session(eye_tracker.current_session)
        
        # Create response with CSV file
        stream = io.StringIO(csv_content)
        filename = f"eyetracking_session_{session_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        response = StreamingResponse(
            iter([stream.getvalue()]),
            media_type="text/csv",
            headers={'Content-Disposition': f'attachment; filename="{filename}"'}
        )
        
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/sessions/{session_id}/end", response_model=SessionResponse)
async def end_session(session_id: str):
    """End an eye tracking session"""
    try:
        if not eye_tracker.current_session or str(eye_tracker.current_session.get('id')) != session_id:
            raise HTTPException(status_code=404, detail="Session not found")
        
        session_data = eye_tracker.end_session()
        return session_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
