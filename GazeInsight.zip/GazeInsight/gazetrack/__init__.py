"""
GazeTrack - A comprehensive eye tracking research platform
"""

__version__ = "0.1.0"
