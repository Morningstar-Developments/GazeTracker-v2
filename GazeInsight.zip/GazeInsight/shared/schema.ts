import { pgTable, text, serial, integer, jsonb, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  settings: jsonb("settings").notNull(),
  calibrationScore: integer("calibration_score"),
  experimentName: text("experiment_name"),
  participantId: text("participant_id"),
});

export const gazeData = pgTable("gaze_data", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  x: real("x").notNull(),  // Changed to real for more precise coordinates
  y: real("y").notNull(),
  confidence: real("confidence").notNull(),
  pupilSize: real("pupil_size"),  // Added pupil size tracking
  event: text("event"),  // For tracking specific events during experiment
  screenSection: text("screen_section"),  // To track which part of screen was viewed
});

// Enhanced schema that accepts ISO date strings and converts them to Date objects
export const insertSessionSchema = createInsertSchema(sessions)
  .pick({
    startTime: true,
    settings: true,
    experimentName: true,
    participantId: true,
  })
  .transform((data) => ({
    ...data,
    startTime: new Date(data.startTime),
  }));

export const insertGazeDataSchema = createInsertSchema(gazeData)
  .pick({
    sessionId: true,
    timestamp: true,
    x: true,
    y: true,
    confidence: true,
    pupilSize: true,
    event: true,
    screenSection: true,
  })
  .transform((data) => ({
    ...data,
    timestamp: new Date(data.timestamp),
  }));

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;
export type InsertGazeData = z.infer<typeof insertGazeDataSchema>;
export type GazeData = typeof gazeData.$inferSelect;