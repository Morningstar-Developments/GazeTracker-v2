import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface CalibrationOverlayProps {
  onComplete: () => void;
}

const CALIBRATION_POINTS = [
  { x: "10%", y: "10%" },
  { x: "90%", y: "10%" },
  { x: "50%", y: "50%" },
  { x: "10%", y: "90%" },
  { x: "90%", y: "90%" },
];

export default function CalibrationOverlay({ onComplete }: CalibrationOverlayProps) {
  const [currentPoint, setCurrentPoint] = useState(0);

  useEffect(() => {
    if (currentPoint >= CALIBRATION_POINTS.length) {
      onComplete();
      return;
    }

    const timer = setTimeout(() => {
      setCurrentPoint(currentPoint + 1);
    }, 2000);

    return () => clearTimeout(timer);
  }, [currentPoint, onComplete]);

  return (
    <div className="absolute inset-0 bg-black bg-opacity-50">
      <AnimatePresence mode="wait">
        {currentPoint < CALIBRATION_POINTS.length && (
          <motion.div
            key={currentPoint}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            className="absolute w-6 h-6"
            style={{
              left: CALIBRATION_POINTS[currentPoint].x,
              top: CALIBRATION_POINTS[currentPoint].y,
              transform: "translate(-50%, -50%)",
            }}
          >
            <div className="w-full h-full rounded-full bg-[#E74C3C] animate-ping" />
            <div className="absolute inset-0 w-full h-full rounded-full bg-[#E74C3C]" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
