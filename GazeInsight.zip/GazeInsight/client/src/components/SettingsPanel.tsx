import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Settings } from "lucide-react";

export default function SettingsPanel() {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="w-5 h-5 text-[#2C3E50]" />
        <h2 className="text-lg font-semibold">Settings</h2>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label>Tracking Accuracy</Label>
          <Slider
            defaultValue={[75]}
            max={100}
            step={1}
            className="[&_[role=slider]]:bg-[#3498DB]"
          />
        </div>

        <div className="flex items-center justify-between">
          <Label>Show Gaze Point</Label>
          <Switch defaultChecked />
        </div>

        <div className="flex items-center justify-between">
          <Label>Real-time Heatmap</Label>
          <Switch />
        </div>

        <div className="flex items-center justify-between">
          <Label>Data Collection</Label>
          <Switch defaultChecked />
        </div>
      </div>
    </Card>
  );
}
