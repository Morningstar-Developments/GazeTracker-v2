import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import CalibrationOverlay from "./CalibrationOverlay";
import { initGazeCloud, startTracking, stopTracking } from "@/lib/gazecloud";
import type { Session } from "@shared/schema";

interface ExperimentSettings {
  experimentName?: string;
  participantId?: string;
}

export default function EyeTracker({ settings }: { settings?: ExperimentSettings }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [isTracking, setIsTracking] = useState(false);
  const { toast } = useToast();

  const { data: session } = useQuery<Session>({
    queryKey: ["/api/sessions/current"],
    enabled: isTracking,
  });

  const startSessionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/sessions", {
        startTime: new Date().toISOString(),
        settings: { 
          accuracy: "high",
          pupilTracking: true,
          screenResolution: {
            width: window.innerWidth,
            height: window.innerHeight
          }
        },
        experimentName: settings?.experimentName || "Default Experiment",
        participantId: settings?.participantId || `P${Date.now()}`,
      });
      const data = await res.json();
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions/current"] });
      toast({
        title: "Session Started",
        description: "Eye tracking session has begun.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to start session",
      });
      setIsTracking(false);
      setIsCalibrating(false);
    },
  });

  const addGazeDataMutation = useMutation({
    mutationFn: async (data: { 
      x: number; 
      y: number; 
      confidence: number;
      pupilSize?: number;
      event?: string;
      screenSection?: string;
    }) => {
      if (!session) return;

      // Calculate screen section
      const screenSection = calculateScreenSection(data.y);

      const res = await apiRequest("POST", `/api/sessions/${session.id}/gaze`, {
        ...data,
        timestamp: new Date().toISOString(),
        screenSection,
      });
      return res.json();
    },
    onError: (error) => {
      console.error("Failed to save gaze data:", error);
    },
  });

  const calculateScreenSection = (y: number): string => {
    const height = window.innerHeight;
    if (y < height / 3) return "top";
    if (y < (height * 2) / 3) return "middle";
    return "bottom";
  };

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const onGazeData = ({ 
      x, 
      y, 
      confidence,
      pupilSize = 0  // GazeCloud API might provide this
    }: { 
      x: number; 
      y: number; 
      confidence: number;
      pupilSize?: number;
    }) => {
      try {
        // Draw gaze point
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.beginPath();
        ctx.arc(x, y, 10, 0, 2 * Math.PI);
        ctx.fillStyle = `rgba(52, 152, 219, ${confidence})`;
        ctx.fill();

        // Send gaze data to server
        addGazeDataMutation.mutate({ 
          x, 
          y, 
          confidence,
          pupilSize,
          event: "gaze_point"  // Default event type
        });
      } catch (error) {
        console.error("Error processing gaze data:", error);
      }
    };

    if (isTracking) {
      try {
        initGazeCloud();
        startTracking(onGazeData);
      } catch (error) {
        console.error("Error initializing eye tracking:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to initialize eye tracking",
        });
        setIsTracking(false);
      }
    }

    return () => {
      if (isTracking) {
        try {
          stopTracking();
        } catch (error) {
          console.error("Error stopping eye tracking:", error);
        }
      }
    };
  }, [isTracking]);

  const handleStartTracking = async () => {
    try {
      setIsCalibrating(true);
      await startSessionMutation.mutateAsync();
      setIsTracking(true);
    } catch (error) {
      console.error("Error starting tracking:", error);
      setIsCalibrating(false);
      setIsTracking(false);
    }
  };

  return (
    <div className="relative aspect-video bg-white rounded-lg overflow-hidden">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        width={1280}
        height={720}
      />
      {isCalibrating && (
        <CalibrationOverlay onComplete={() => setIsCalibrating(false)} />
      )}
      {!isTracking && !isCalibrating && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={handleStartTracking}
            className="bg-[#3498DB] text-white px-6 py-3 rounded-lg font-semibold hover:bg-opacity-90"
          >
            Start Eye Tracking
          </button>
        </div>
      )}
    </div>
  );
}