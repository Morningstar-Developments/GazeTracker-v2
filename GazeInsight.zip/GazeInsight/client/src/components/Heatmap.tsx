import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import type { GazeData } from "@shared/schema";
import * as d3 from "d3";

export default function Heatmap() {
  const svgRef = useRef<SVGSVGElement>(null);
  
  const { data: gazeData } = useQuery<GazeData[]>({
    queryKey: ["/api/sessions/current/gaze"],
  });

  useEffect(() => {
    if (!svgRef.current || !gazeData?.length) return;

    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const hexbin = d3.hexbin()
      .radius(20)
      .extent([[0, 0], [width, height]]);

    const points = gazeData.map(d => [d.x, d.y]);
    const bins = hexbin(points);

    const color = d3.scaleSequential(d3.interpolateYlOrRd)
      .domain([0, d3.max(bins, d => d.length) || 0]);

    svg.append("g")
      .selectAll("path")
      .data(bins)
      .enter().append("path")
      .attr("d", hexbin.hexagon())
      .attr("transform", d => `translate(${d.x},${d.y})`)
      .attr("fill", d => color(d.length))
      .attr("opacity", 0.7);

  }, [gazeData]);

  return (
    <div className="relative aspect-video bg-white rounded-lg overflow-hidden">
      <svg
        ref={svgRef}
        className="w-full h-full"
        viewBox="0 0 1280 720"
      />
    </div>
  );
}
