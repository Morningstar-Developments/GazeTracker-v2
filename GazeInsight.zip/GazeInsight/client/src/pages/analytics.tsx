import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Eye, Download, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import type { Session, GazeData } from "@shared/schema";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  ScatterChart,
  Scatter,
} from "recharts";
import * as d3 from "d3";
import { useMemo } from "react";

interface SessionAnalytics {
  totalDuration: number;
  averageConfidence: number;
  dataPoints: number;
  coverage: {
    top: number;
    middle: number;
    bottom: number;
  };
}

function calculateAnalytics(gazeData: GazeData[]): SessionAnalytics {
  if (!gazeData.length) {
    return {
      totalDuration: 0,
      averageConfidence: 0,
      dataPoints: 0,
      coverage: { top: 0, middle: 0, bottom: 0 },
    };
  }

  const confidence = gazeData.reduce((sum, d) => sum + d.confidence, 0);
  const duration = Math.abs(
    new Date(gazeData[gazeData.length - 1].timestamp).getTime() -
    new Date(gazeData[0].timestamp).getTime()
  );

  // Calculate screen coverage
  const screenSections = gazeData.reduce(
    (acc, d) => {
      if (d.y < 240) acc.top++;
      else if (d.y < 480) acc.middle++;
      else acc.bottom++;
      return acc;
    },
    { top: 0, middle: 0, bottom: 0 }
  );

  const total = gazeData.length;
  return {
    totalDuration: duration / 1000, // Convert to seconds
    averageConfidence: confidence / total,
    dataPoints: total,
    coverage: {
      top: (screenSections.top / total) * 100,
      middle: (screenSections.middle / total) * 100,
      bottom: (screenSections.bottom / total) * 100,
    },
  };
}

function SessionCard({ session }: { session: Session }) {
  const { data: gazeData, isLoading: isLoadingGaze } = useQuery<GazeData[]>({
    queryKey: [`/api/sessions/${session.id}/gaze`],
  });

  const analytics = useMemo(() => {
    if (!gazeData) return null;
    return calculateAnalytics(gazeData);
  }, [gazeData]);

  const { toast } = useToast();

  const handleExport = async () => {
    try {
      const response = await fetch(`/api/sessions/${session.id}/export`);
      if (!response.ok) throw new Error('Failed to export session data');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `session-${session.id}-${new Date().toISOString()}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export Successful",
        description: "Session data has been exported to CSV",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: error instanceof Error ? error.message : "Failed to export session data",
      });
    }
  };

  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Session {session.id}</h2>
        <Button
          variant="outline"
          className="flex items-center gap-2"
          onClick={handleExport}
        >
          <Download className="w-4 h-4" />
          Export CSV
        </Button>
      </div>

      {isLoadingGaze ? (
        <div className="h-[400px] flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      ) : !gazeData?.length ? (
        <div className="h-[400px] flex items-center justify-center text-muted-foreground">
          No gaze data available
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Duration</h3>
              <p className="text-2xl font-bold">{analytics?.totalDuration.toFixed(1)}s</p>
            </Card>
            <Card className="p-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Data Points</h3>
              <p className="text-2xl font-bold">{analytics?.dataPoints}</p>
            </Card>
            <Card className="p-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Avg. Confidence</h3>
              <p className="text-2xl font-bold">{(analytics?.averageConfidence || 0).toFixed(2)}%</p>
            </Card>
            <Card className="p-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Screen Coverage</h3>
              <div className="space-y-1">
                <div className="text-xs">Top: {analytics?.coverage.top.toFixed(1)}%</div>
                <div className="text-xs">Middle: {analytics?.coverage.middle.toFixed(1)}%</div>
                <div className="text-xs">Bottom: {analytics?.coverage.bottom.toFixed(1)}%</div>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="h-[300px]">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Gaze Position</h3>
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid />
                  <XAxis type="number" dataKey="x" name="x" domain={[0, 1280]} />
                  <YAxis type="number" dataKey="y" name="y" domain={[0, 720]} />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                  <Scatter
                    name="Gaze Points"
                    data={gazeData}
                    fill="#3498DB"
                    opacity={0.5}
                  />
                </ScatterChart>
              </ResponsiveContainer>
            </div>

            <div className="h-[300px]">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Confidence Over Time</h3>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={gazeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="timestamp"
                    tickFormatter={(time) => new Date(time).toLocaleTimeString()}
                  />
                  <YAxis domain={[0, 100]} />
                  <Tooltip
                    labelFormatter={(label) => new Date(label).toLocaleTimeString()}
                  />
                  <Line
                    type="monotone"
                    dataKey="confidence"
                    stroke="#3498DB"
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </Card>
  );
}

export default function Analytics() {
  const { data: sessions, isLoading } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
  });

  return (
    <div className="min-h-screen bg-[#F8F9FA] p-6">
      <nav className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-2">
          <Eye className="w-6 h-6 text-[#2C3E50]" />
          <h1 className="text-2xl font-bold text-[#2C3E50]">GazeTrack Pro</h1>
        </div>
        <Link href="/">
          <Button variant="outline" className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Tracking
          </Button>
        </Link>
      </nav>

      {isLoading ? (
        <div className="flex items-center justify-center min-h-[200px]">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      ) : !sessions?.length ? (
        <Card className="p-6">
          <div className="text-center text-muted-foreground">
            No sessions recorded yet. Start eye tracking to collect data.
          </div>
        </Card>
      ) : (
        <div className="grid gap-6">
          {sessions.map((session) => (
            <SessionCard key={session.id} session={session} />
          ))}
        </div>
      )}
    </div>
  );
}