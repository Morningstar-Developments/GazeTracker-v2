import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EyeTracker from "@/components/EyeTracker";
import Heatmap from "@/components/Heatmap";
import SettingsPanel from "@/components/SettingsPanel";
import { Link } from "wouter";
import { BarChart3, Eye } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#F8F9FA] p-6">
      <nav className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-2">
          <Eye className="w-6 h-6 text-[#2C3E50]" />
          <h1 className="text-2xl font-bold text-[#2C3E50]">GazeTrack Pro</h1>
        </div>
        <Link href="/analytics">
          <Button variant="outline" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Analytics
          </Button>
        </Link>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <Card className="p-6">
            <Tabs defaultValue="live">
              <TabsList>
                <TabsTrigger value="live">Live Tracking</TabsTrigger>
                <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
              </TabsList>
              <TabsContent value="live">
                <EyeTracker />
              </TabsContent>
              <TabsContent value="heatmap">
                <Heatmap />
              </TabsContent>
            </Tabs>
          </Card>
        </div>
        <div className="lg:col-span-1">
          <SettingsPanel />
        </div>
      </div>
    </div>
  );
}
