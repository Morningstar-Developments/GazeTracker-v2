import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSessionSchema, insertGazeDataSchema } from "@shared/schema";
import { formatSessionDataToCsv } from "./utils/csv";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/sessions", async (req, res) => {
    const parsed = insertSessionSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }

    const session = await storage.createSession(parsed.data);
    res.json(session);
  });

  app.patch("/api/sessions/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid session ID" });
    }

    const session = await storage.updateSession(id, req.body);
    res.json(session);
  });

  app.get("/api/sessions/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid session ID" });
    }

    const session = await storage.getSession(id);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }
    res.json(session);
  });

  // New endpoint for CSV export
  app.get("/api/sessions/:id/export", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }

      const session = await storage.getSession(id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }

      const gazeData = await storage.getSessionGazeData(id);
      const csvData = formatSessionDataToCsv(session, gazeData);

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=session-${id}-${new Date().toISOString()}.csv`);
      res.send(csvData);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to export session data" 
      });
    }
  });

  app.post("/api/sessions/:id/gaze", async (req, res) => {
    const sessionId = parseInt(req.params.id);
    if (isNaN(sessionId)) {
      return res.status(400).json({ error: "Invalid session ID" });
    }

    const parsed = insertGazeDataSchema.safeParse({ ...req.body, sessionId });
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }

    const data = await storage.addGazeData(parsed.data);
    res.json(data);
  });

  app.get("/api/sessions/:id/gaze", async (req, res) => {
    const sessionId = parseInt(req.params.id);
    if (isNaN(sessionId)) {
      return res.status(400).json({ error: "Invalid session ID" });
    }

    const data = await storage.getSessionGazeData(sessionId);
    res.json(data);
  });

  const httpServer = createServer(app);
  return httpServer;
}