import { Session, GazeData } from "@shared/schema";
import { log } from "../vite";

/**
 * Formats session data and gaze tracking information into a well-structured CSV format.
 * The CSV is organized into distinct sections:
 * 1. Session Information - Basic session metadata
 * 2. Settings - Session configuration details
 * 3. Experiment Details - Participant and experiment information
 * 4. Gaze Data - Detailed eye tracking metrics with timestamps
 */
export function formatSessionDataToCsv(session: Session, gazeData: GazeData[]): string {
  try {
    // Helper function to escape CSV fields
    const escapeField = (value: string | null | undefined) => {
      if (!value) return '';
      if (value.includes(',') || value.includes('"') || value.includes('\n')) {
        return `"${value.replace(/"/g, '""')}"`;
      }
      return value;
    };

    // Format session metadata section
    const sessionMetadata = [
      '# Session Information',
      'Session ID,Start Time,End Time,Calibration Score,Experiment Name,Participant ID',
      `${session.id},${session.startTime.toISOString()},${session.endTime?.toISOString() || 'N/A'},${session.calibrationScore || 'N/A'},${escapeField(session.experimentName)},${escapeField(session.participantId)}`,
      '',  // Empty line for visual separation
    ];

    // Format settings section
    const settingsSection = [
      '# Settings',
      'Setting Name,Value',
      ...Object.entries(session.settings as Record<string, unknown>).map(([key, value]) => 
        `${escapeField(key)},${escapeField(String(value))}`
      ),
      '',  // Empty line for visual separation
    ];

    // Calculate basic analytics
    const analytics = calculateSessionAnalytics(gazeData);
    const analyticsSection = [
      '# Session Analytics',
      'Metric,Value',
      `Total Duration (s),${analytics.duration}`,
      `Average Confidence,${analytics.avgConfidence}`,
      `Data Points,${analytics.dataPoints}`,
      `Screen Coverage Top %,${analytics.coverage.top}`,
      `Screen Coverage Middle %,${analytics.coverage.middle}`,
      `Screen Coverage Bottom %,${analytics.coverage.bottom}`,
      '',
    ];

    // Format gaze data section with enhanced fields
    const gazeDataSection = [
      '# Gaze Tracking Data',
      'Timestamp,X Position,Y Position,Confidence,Pupil Size,Event,Screen Section',
      ...gazeData.map(data => [
        data.timestamp.toISOString(),
        data.x.toString(),
        data.y.toString(),
        data.confidence.toString(),
        data.pupilSize?.toString() || 'N/A',
        data.event || 'N/A',
        data.screenSection || 'N/A'
      ].join(','))
    ];

    // Combine all sections
    const csvContent = [
      ...sessionMetadata,
      ...settingsSection,
      ...analyticsSection,
      ...gazeDataSection
    ].join('\n');

    log(`Successfully formatted CSV data for session ${session.id} with ${gazeData.length} gaze data points`);
    return csvContent;

  } catch (error) {
    const errorMessage = `Error formatting CSV data for session ${session.id}: ${error instanceof Error ? error.message : String(error)}`;
    log(errorMessage);
    throw new Error(errorMessage);
  }
}

function calculateSessionAnalytics(gazeData: GazeData[]) {
  if (!gazeData.length) {
    return {
      duration: 0,
      avgConfidence: 0,
      dataPoints: 0,
      coverage: { top: 0, middle: 0, bottom: 0 }
    };
  }

  const duration = (new Date(gazeData[gazeData.length - 1].timestamp).getTime() - 
                   new Date(gazeData[0].timestamp).getTime()) / 1000;

  const avgConfidence = gazeData.reduce((sum, d) => sum + d.confidence, 0) / gazeData.length;

  const screenSections = gazeData.reduce((acc, d) => {
    if (d.y < 240) acc.top++;
    else if (d.y < 480) acc.middle++;
    else acc.bottom++;
    return acc;
  }, { top: 0, middle: 0, bottom: 0 });

  return {
    duration,
    avgConfidence,
    dataPoints: gazeData.length,
    coverage: {
      top: (screenSections.top / gazeData.length) * 100,
      middle: (screenSections.middle / gazeData.length) * 100,
      bottom: (screenSections.bottom / gazeData.length) * 100
    }
  };
}