import { sessions, gazeData, type Session, type InsertSession, type GazeData, type InsertGazeData } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { log } from "./vite";

export interface IStorage {
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: number, session: Partial<Session>): Promise<Session>;
  getSession(id: number): Promise<Session | undefined>;
  addGazeData(data: InsertGazeData): Promise<GazeData>;
  getSessionGazeData(sessionId: number): Promise<GazeData[]>;
}

export class DatabaseStorage implements IStorage {
  async createSession(insertSession: InsertSession): Promise<Session> {
    try {
      log(`Creating new session with settings: ${JSON.stringify(insertSession.settings)}`);
      const [session] = await db
        .insert(sessions)
        .values({
          ...insertSession,
          startTime: new Date(insertSession.startTime), // Parse ISO string to Date
        })
        .returning();
      log(`Created session with ID: ${session.id}`);
      return session;
    } catch (error) {
      log(`Error creating session: ${error instanceof Error ? error.message : String(error)}`);
      throw new Error(`Failed to create session: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async updateSession(id: number, sessionUpdate: Partial<Session>): Promise<Session> {
    try {
      log(`Updating session ${id} with: ${JSON.stringify(sessionUpdate)}`);
      const [session] = await db
        .update(sessions)
        .set(sessionUpdate)
        .where(eq(sessions.id, id))
        .returning();
      if (!session) {
        const error = `Session ${id} not found`;
        log(error);
        throw new Error(error);
      }
      log(`Updated session ${id}`);
      return session;
    } catch (error) {
      log(`Error updating session ${id}: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  }

  async getSession(id: number): Promise<Session | undefined> {
    try {
      log(`Fetching session ${id}`);
      const [session] = await db
        .select()
        .from(sessions)
        .where(eq(sessions.id, id));
      log(session ? `Found session ${id}` : `Session ${id} not found`);
      return session;
    } catch (error) {
      log(`Error fetching session ${id}: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  }

  async addGazeData(insertData: InsertGazeData): Promise<GazeData> {
    try {
      const [data] = await db
        .insert(gazeData)
        .values({
          ...insertData,
          timestamp: new Date(insertData.timestamp), // Parse ISO string to Date
        })
        .returning();
      return data;
    } catch (error) {
      log(`Error adding gaze data: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  }

  async getSessionGazeData(sessionId: number): Promise<GazeData[]> {
    try {
      log(`Fetching gaze data for session ${sessionId}`);
      const data = await db
        .select()
        .from(gazeData)
        .where(eq(gazeData.sessionId, sessionId));
      log(`Found ${data.length} gaze data points for session ${sessionId}`);
      return data;
    } catch (error) {
      log(`Error fetching gaze data for session ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();