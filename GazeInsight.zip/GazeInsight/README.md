# GazeTrack

A comprehensive eye tracking research platform leveraging computer vision for advanced scientific data collection and visualization.

## Features

- Real-time eye tracking data collection
- Advanced gaze analysis and visualization
- CSV data export with detailed analytics
- Research-grade eye movement analysis tools
- Experiment session management
- Screen coverage analysis
- Pupil size tracking
- Fixation and saccade detection

## Installation

```bash
pip install gazetrack
```

## Quick Start

```python
from gazetrack.core.eye_tracker import EyeTracker
from gazetrack.core.data_processor import GazeDataProcessor
from gazetrack.core.csv_exporter import CSVExporter

# Initialize eye tracker
tracker = EyeTracker()

# Start a session
session = tracker.start_session(
    experiment_name="Visual Attention Study",
    participant_id="P001"
)

# Process and analyze data
processor = GazeDataProcessor()
analytics = processor.process_session(session)

# Export to CSV
exporter = CSVExporter()
csv_data = exporter.export_session(session)
```

## API Usage

Start the API server:

```bash
uvicorn gazetrack.api.main:app --host 0.0.0.0 --port 8000
```

The API documentation will be available at `http://localhost:8000/docs`.

## Documentation

For detailed documentation, visit [documentation link].

## License

This project is licensed under the MIT License - see the LICENSE file for details.
